var ctx, ctx2, ctx3
var canvas = document.getElementById('layer1'); //Jogo
var canvas2 = document.getElementById('layer2');//Butoes e Timers
var canvas3 = document.getElementById('layer3');//Fundo

//CANVAS
//--------------------------------------------------------------------------------------
var areaJogo = {
    start: function () {
        canvas2.width = 750;
        canvas2.height = 608;
        ctx2 = canvas2.getContext("2d");
        canvas3.width = 750;
        canvas3.height = 608;
        ctx3 = canvas3.getContext("2d");
        canvas.width = 750;
        canvas.height = 608;
        ctx = canvas.getContext("2d");
    }
}
//--------------------------------------------------------------------------------------
//Opening

//Operadores
var Imgmais = new Image();
var Imgmenos = new Image();
var Imgvezes = new Image();
var Imgdividir = new Image();
Imgmais.src = 'mais.png';
Imgmenos.src = 'menos.png';
Imgvezes.src = 'vezes.png';
Imgdividir.src = 'dividir.png';
//Quantidade Perguntas
var Img5p = new Image();
var Img10p = new Image();
var Img15p = new Image();
var Img20p = new Image();
Img5p.src = '5.png';
Img10p.src = '10.png';
Img15p.src = '15.png';
Img20p.src = '20.png';
//Confirmar - Retroceder
var ImgBack = new Image();
var ImgContinue = new Image();
ImgBack.src = "Back.png"
ImgContinue.src = "continue.png"

function ButoesOpcoes(img, x, y) {
    this.x = x
    this.y = y
    this.w = 100;
    this.h = 100;
    this.flag = false;
    this.desenhaMenu = function () {
        if (this.flag == false) {
            ctx.drawImage(img, this.x, this.y, this.w, this.h)
        }
        if (this.flag == true) {
            ctx.drawImage(Alvomarcado, this.x, this.y, this.w, this.h)
        }
    }
}
ButoesOpcoes.prototype.isInside = function (mx, my) { //deteta o rato nos botoes
    return (mx >= this.x) && (mx <= this.x + this.w) && (my >= this.y) && (my <= this.y + this.h);
}
function ButoesConfirm(img, x, y) {
    this.x = x
    this.y = y
    this.w = 200;
    this.h = 50;
    this.desenhaMenu = function () {
        ctx.drawImage(img, this.x, this.y)
    }
}
ButoesConfirm.prototype.isInside = function (mx, my) {
    return (mx >= this.x) && (mx <= this.x + this.w) && (my >= this.y) && (my <= this.y + this.h);
}
var ObjetosOpcoes = []
var ObjetosConfirm = []
var Opcao1 = new ButoesOpcoes(Imgmais, 50, 150)
var Opcao2 = new ButoesOpcoes(Imgmenos, 200, 150)
var Opcao3 = new ButoesOpcoes(Imgvezes, 350, 150)
var Opcao4 = new ButoesOpcoes(Imgdividir, 500, 150)
var Opcao5 = new ButoesOpcoes(Img5p, 50, 350)
var Opcao6 = new ButoesOpcoes(Img10p, 200, 350)
var Opcao7 = new ButoesOpcoes(Img15p, 350, 350)
var Opcao8 = new ButoesOpcoes(Img20p, 500, 350)
ObjetosOpcoes.push(Opcao1)
ObjetosOpcoes.push(Opcao2)
ObjetosOpcoes.push(Opcao3)
ObjetosOpcoes.push(Opcao4)
ObjetosOpcoes.push(Opcao5)
ObjetosOpcoes.push(Opcao6)
ObjetosOpcoes.push(Opcao7)
ObjetosOpcoes.push(Opcao8)
var confirmar = new ButoesConfirm(ImgContinue, 400, 490)
var back = new ButoesConfirm(ImgBack, 150, 490)
ObjetosConfirm.push(confirmar)
ObjetosConfirm.push(back)

function OpcoesMenu() {
    ctx.clearRect(0, 0, 750, 680)
    ctx.beginPath();
    ctx.font = "40px Baloo Bhaina"
    ctx.fillStyle = 'rgba(255,255,255,0.8)'
    ctx.textAlign = "left"
    ctx.fillText("Operador", 50, 100)
    ctx.fillText("Número de Perguntas", 50, 300)
    for (var i = 0; i < ObjetosOpcoes.length; i++) {
        ObjetosOpcoes[i].desenhaMenu()  //intera sobre o array para desenhar os objetos
    }

    for (var i = 0; i < ObjetosConfirm.length; i++) {
        ObjetosConfirm[i].desenhaMenu()
    }

}

//--------------------------------------------------------------------------------------
//Desenha Fundo
function Fundo() {
    var Image1 = new Image();
    Image1.src = 'border.png';
    Image1.onload = function () {
        var Pattern1 = ctx3.createPattern(Image1, 'repeat');
        ctx3.beginPath()
        ctx3.strokeStyle = Pattern1;
        ctx3.lineWidth = 40;
        ctx3.strokeRect(0, 0, 750, 608);
    }
    var Image2 = new Image();
    Image2.src = 'fundo.png';
    Image2.onload = function () {
        var Pattern2 = ctx3.createPattern(Image2, 'repeat');
        ctx3.beginPath();
        ctx3.fillStyle = Pattern2;
        ctx3.fillRect(0, 0, 750, 600);
    }


}
//--------------------------------------------------------------------------------------
//Ecra de Inicio
//--------------------------------------------------------------------------------------
function ButoesPrincipal(x, y, w, h, text) {
    this.x = x
    this.y = y
    this.w = w
    this.h = h
    this.text = text

    this.desenhaMenu = function () {
        ctx.fillStyle = 'rgba(0,50,255,0.6)'
        ctx.strokeStyle = 'black'
        ctx.font = '40px Baloo Bhaina'
        ctx.lineWidth = 3;
        ctx.textAlign = "center"
        ctx.beginPath()
        ctx.fillRect(this.x, this.y, this.w, this.h)
        ctx.strokeRect(this.x, this.y, this.w, this.h)
        ctx.fillStyle = 'white'
        ctx.fillText(this.text, this.x + (this.w / 2), this.y + this.h / 2 + 10)
        ctx.closePath()
    }
}
ButoesPrincipal.prototype.isInside = function (mx, my) {
    return (mx >= this.x) && (mx <= this.x + this.w) && (my >= this.y) && (my <= this.y + this.h);
}
//--------------------------------------------------------------------------------------
var OpcoesO, HighScoresO, startO
function StartMenu() {
    startO = new ButoesPrincipal(250, 175, 250, 80, "Start");
    // HighScoresO = new ButoesPrincipal(250, 250, 250, 80, "High Scores");
    OpcoesO = new ButoesPrincipal(250, 325, 250, 80, "Options");
    startO.desenhaMenu()
    //HighScoresO.desenhaMenu()
    OpcoesO.desenhaMenu()
}
//--------------------------------------------------------------------------------------
//Definições de Jogo
//--------------------------------------------------------------------------------------
var ScreenFlag = 0;
var PerguntasModo = [5, 10, 15, 20]
var OperadoresArr = ["+", "-", "*", "/"]
var res = [];
var ContaTexto;
var tempojogo = 0;
function Settings(Qtd, Operador) {
    res = [];
    ContaTexto = [];
    var QtdPerguntas = Qtd;
    var PergCertas = QtdPerguntas;
    this.Operador = Operador;
    var Multiplier = [1, 1.25, 1.50, 1, 80];
    var SelectMulti = 0;
    var indexOper;
    var tempoBase = 300000;
    var EspaçoRandom = 0;
    var rnum1, rnum2;
    var resTemp;
    //Dificuldade
    //--------------------------------------------------------------------------------------
    switch (this.Operador) {
        case "+": indexOper = 0
            ScoreMulti = 0
            EspaçoRandom = 9
            tempojogo = tempoBase * 0.30
            break;
        case "-": indexOper = 1
            ScoreMulti = 1
            EspaçoRandom = 9
            tempojogo = tempoBase * 0.50
            break;
        case "*": indexOper = 2
            ScoreMulti = 2
            EspaçoRandom = 9
            tempojogo = tempoBase * 0.80
            break;
        case "/": indexOper = 3
            ScoreMulti = 3
            EspaçoRandom = 9
            tempojogo = tempoBase * 1
            break;
    }
    //Bonus de Tempo baseado na quantidade de perguntas
    //--------------------------------------------------------------------------------------
    switch (QtdPerguntas) {
        case 5:
            tempojogo = tempojogo * 1
            break;
        case 10:
            tempojogo = tempojogo * 1
            break;
        case 15:
            tempojogo = tempojogo * 1.20
            break;
        case 20:
            tempojogo = tempojogo * 1.50
            break;
    }
    //--------------------------------------------------------------------------------------
    //1º ciclo para criar as perguntas e guardar respostas no array
    var flag = false;
    for (var i = 0; i < PergCertas; i++) {
        //Cria numeros para fazer conta
        rnum1 = 1 + Math.round(Math.random() * EspaçoRandom)
        rnum2 = 1 + Math.round(Math.random() * EspaçoRandom)
        //Procede ao calculo
        switch (indexOper) {
            case 0: resTemp = rnum1 + rnum2; break;
            case 1: resTemp = rnum1 - rnum2; break;
            case 2: resTemp = rnum1 * rnum2; break;
            case 3: resTemp = rnum1 / rnum2; break;
        }
        /*Verifica se o Array tem algum resultado igual
        para evitar repetição dos numeros nos alvos e de contas
        */
        for (var j = 0; j < res.length; j++) {
            if (res[j] == resTemp || resTemp == Infinity) {
                flag = true;
            }
        }
        //Caso nao tenha, guarda no array, e guarda o calculo
        if (flag == false) {
            res.push(resTemp)
            switch (indexOper) {
                case 0: ContaTexto.push(rnum1 + "+" + rnum2); break;
                case 1: ContaTexto.push(rnum1 + "-" + rnum2); break;
                case 2: ContaTexto.push(rnum1 + "*" + rnum2); break;
                case 3: ContaTexto.push(rnum1 + "/" + rnum2); break;
            }
        }
        else {
            PergCertas++;
            flag = false;
        }
    }
    //--------------------------------------------------------------------------------------
    //2º ciclo para criar as respostas erradas
    flag = false;
    var PergErradas = 36 - QtdPerguntas
    for (var i = 0; i < PergErradas; i++) {
        flag = false;
        rnum1 = 1 + Math.round(Math.random() * EspaçoRandom)
        rnum2 = 1 + Math.round(Math.random() * EspaçoRandom)
        indexOper = Math.round(Math.random() * 3);
        switch (indexOper) {
            case 0: resTemp = rnum1 + rnum2; break;
            case 1: resTemp = rnum1 - rnum2; break;
            case 2: resTemp = rnum1 * rnum2; break;
            case 3: resTemp = rnum1 / rnum2; break;
        }
        for (var j = 0; j < res.length; j++) {
            if (res[j] == resTemp || resTemp == Infinity) {
                flag = true;
            }
        }
        if (flag == false) {
            res.push(resTemp)
        }
        else {
            PergErradas++;
            flag = false;
        }
    }
}
//--------------------------------------------------------------------------------------
//Quadrados
//--------------------------------------------------------------------------------------
var PosIX = 0
var PosIY = 100
var widthQ = 100
var heightQ = 100
var ArrayQuadrados1 = [];
var ArrayQuadrados2 = [];
var ArrayQuadrados3 = [];
var img = new Image();
img.src = 'Target.png';
var Alvomarcado = new Image();
Alvomarcado.src = "TargetShot.png"
function AlvosConfig(x, y, w, h, text) {
    this.x = x
    this.y = y
    this.w = w
    this.h = h
    this.img = img;
    this.text = text
    this.color = "black";
    // 0=falhou o alvo ou acertou na resposta
    //2 = acertou no alvo errado
    this.AlvoErrado = 0;
    this.conta = 0;
    this.DesenhaAlvos = function () {

        ctx.strokeStyle = 'black'
        ctx.font = '40px Baloo Bhaina'
        ctx.lineWidth = 1;
        ctx.textAlign = "center"
        ctx.beginPath()
        ctx.drawImage(this.img, this.x, this.y, 100, 100);
        //!!Check de cor de Texto!!
        //Predifinição
        if (this.AlvoErrado == 0) {
            ctx.fillStyle = "#ffffff"
        }
        else if (this.AlvoErrado == 2) {
            //Fillstyle a vermelho durante 20 incrementações
            if (this.conta < 20) {
                ctx.fillStyle = 'red';
                this.conta++;
            }
            //Apos 20 incrementações faz reset na flag e na contagem
            else {
                this.conta = 0;
                this.AlvoErrado = 0;
            }
        }
        ctx.fillText(this.text, this.x + (this.w / 2), this.y + this.h / 2 + 10)
        ctx.closePath()

    }
    this.atualiza = function () {
        this.x = this.x + 5
        if (this.x >= 1650) {
            this.x = -this.w - 50
        }
    }
    this.atualiza2 = function () {
        this.x = this.x - 5
        if (this.x <= -950) {
            this.x = 750 + this.w
        }
    }
}
/*
Corrige Array de Resultados
Cria Quadrados no Array e associa os Resultados
*/
function criaObjetos(Qtd) {
    ArrayQuadrados1 = []
    ArrayQuadrados2 = []
    ArrayQuadrados3 = []
    this.Qtdquadrados = Qtd;
    for (var i = 0; i < 36; i++) {
        /*Arredonda os numeros para duas casas decimais
        Exemplo seja 30.04074, apresenta 30.04
        */
        if (res[i].toFixed(2).toString().indexOf('.00' == -1)) {
            res[i] = res[i].toFixed(2).toString().replace('.00', '')
        }
        else {
            res[i] = res[i].toFixed(2).toString();
        }
    }
    for (var i = 0; i < this.Qtdquadrados - 24; i++) {
        var quad = new AlvosConfig(PosIX, PosIY, widthQ, heightQ, res[i].toString());
        var quad2 = new AlvosConfig(PosIX, PosIY + 150, widthQ, heightQ, res[i + 12].toString());
        var quad3 = new AlvosConfig(PosIX, PosIY + 300, widthQ, heightQ, res[i + 24].toString());
        ArrayQuadrados1.push(quad)
        ArrayQuadrados2.push(quad2)
        ArrayQuadrados3.push(quad3)
        PosIX = PosIX + 150;
    }
    PosIX = 0;
}

AlvosConfig.prototype.isInside = function (mx, my) {
    return (mx >= this.x) && (mx <= this.x + this.w) && (my >= this.y) && (my <= this.y + this.h);
}


//--------------------------------------------------------------------------------------
//Animação do Jogo
//--------------------------------------------------------------------------------------
function AnimaçãoJogo() {
    ctx.clearRect(0, 0, 750, 608)
    for (var i = 0; i < ArrayQuadrados1.length; i++) {
        ArrayQuadrados1[i].DesenhaAlvos();
        ArrayQuadrados1[i].atualiza();
    }
    for (var i = 0; i < ArrayQuadrados2.length; i++) {
        ArrayQuadrados2[i].DesenhaAlvos();
        ArrayQuadrados2[i].atualiza2();
    }
    for (var i = 0; i < ArrayQuadrados3.length; i++) {
        ArrayQuadrados3[i].DesenhaAlvos();
        ArrayQuadrados3[i].atualiza();
    }
}
//--------------------------------------------------------------------------------------
//Timer Butao Exit e display de Perguntas
//--------------------------------------------------------------------------------------
function ButaoExit(x, y, t) {
    this.x = x
    this.y = y
    this.w = 40
    this.h = 40
    this.text = t
    this.desenhaBut = function () {
        ctx2.beginPath()
        ctx2.fillStyle = 'rgba(0,0,0,0.8)'
        ctx2.font = '40px Baloo Bhaina'
        ctx2.lineWidth = 3;
        ctx2.textAlign = "center"
        ctx2.fillText(this.text, this.x + 40 / 2, this.y + 30)
        // ctx.fillRect(this.x, this.y, this.w, this.h)
        ctx2.closePath()
    }
}
ButaoExit.prototype.isInside = function (mx, my) {
    return (mx >= this.x) && (mx <= this.x + this.w) && (my >= this.y) && (my <= this.y + this.h);
}
//--------------------------------------------------------------------------------------
var Xbut = new ButaoExit(690, 20, "X")
var tamanho = 40;
var timer3;
function tamanh1() {
    tamanho = tamanho * 1.1
}
var perguntaTemp = 0;
var NumQuadrados = 36;
var pp = 0;
var tp = 0;
var pergunta = 0;
var tempcolor = "red"
//--------------------------------------------------------------------------------------
function PergTimer() {
    ctx2.clearRect(0, 0, 750, 608)
    Xbut.desenhaBut()
    console.log(pergunta + " - Perg")
    console.log(perguntaTemp + " - Temp")
    if (pergunta != perguntaTemp) {
        tamanho = tamanho * 1.1;
        tempcolor = "green"
    }
    if (tamanho >= 60) {
        tempcolor = "red"
        tamanho = 40
        perguntaTemp = pergunta;

    }
    if (tp == 1) {
        tp = 0;
        seconds--;
    }
    ctx2.beginPath()
    ctx2.textAlign = "center"
    ctx2.font = tamanho + "px Baloo Bhaina"
    ctx2.fillStyle = tempcolor;
    ctx2.fillText(ContaTexto[pergunta] + " = ?", 375, 580)
    if (seconds > 9) {
        ctx2.font = "40px Baloo Bhaina"
        ctx2.fillText("0" + minutes + ":" + seconds, 100, 580)
    }
    if (seconds <= 9) {
        ctx2.font = "40px Baloo Bhaina"
        ctx2.fillText("0" + minutes + ":" + "0" + seconds, 100, 580)
    }
    if (minutes >= 0 && seconds == 0) {
        minutes--;
        seconds = 59;
    }
    if (minutes == 0 && seconds == 0) {
        seconds = 59;
    }
    pp++
    if (pp == tempojogo / 1000) {
        clearInterval(timer)
        ctx.clearRect(0, 0, 750, 600)
        Fundo()
        ctx.beginPath()
        ctx.fillStyle = "red"
        ctx.font = "40px Baloo Bhaina"
        ctx.textAlign = "center"
        ctx.fillText("GAME OVER", 375, 200)
        ctx.fillText("TIME'S UP!!", 375, 300)
        Xbut.desenhaBut();
        perguntaTemp = 0;
        pergunta = 0;
        tp = 0;
        pp = 0;
    }
    tp++
}
//--------------------------------------------------------------------------------------
//Shuffle Array
function shuffle(array) {
    let counter = array.length;
    // While elementos no array
    while (counter > 0) {
        // Escolhe um index aleatorio
        let index = Math.floor(Math.random() * counter);
        // Reduz contador
        counter--;
        // troca o ultimo elemento com o Index selecionado
        let temp = array[counter];
        array[counter] = array[index];
        array[index] = temp;
    }
    return array;
}


//--------------------------------------------------------------------------------------
//Arranque do Jogo
/*
Inicia os Canvas
Faz o load das settings por defeito
Inicia os valores do timer
Desenha o Fundo do ecra de jogo
Desenha as opções do Menu Inicial
*/
var seconds, minutes
var SelecaoP = 0
var SelecaoO = 0;

function Arranque() {
    areaJogo.start(); //Inicia os canvas
    //Load do timer por defeito

    //---------------------------------------------
    Fundo()
    StartMenu()
    //---------------------------------------------
    //Click
    canvas.addEventListener('click', click);
}
//--------------------------------------------------------------------------------------
window.onload = Arranque()
//--------------------------------------------------------------------------------------
//Mouse Events
//--------------------------------------------------------------------------------------

function EndGame() {
    window.clearInterval(timer)
    window.clearInterval(timer2)
    perguntaTemp = 0;
    pergunta = 0;
    tp = 0;
    pp = 0;
    ctx.clearRect(0, 0, 750, 608)
    ctx2.clearRect(0, 0, 750, 608)
    ctx.beginPath()
    ctx.fillStyle = "red"
    ctx.font = "40px Baloo Bhaina"
    ctx.textAlign = "center"
    ctx.fillText("Congratulations!", 375, 304)
    Xbut.desenhaBut()
}

var timer, timer2;

function click(e) {

    var mX = e.pageX - canvas.offsetLeft;
    var mY = e.pageY - canvas.offsetTop;
    switch (ScreenFlag) {
        /*
        Explicação SCREENFLAG :
        0 - Menu Principal
        1 - HighScores
        2 - Options
        3 - Jogo
        */
        case 0://MENUS & START GAME
            //LOAD DO JOGO
            if (startO.isInside(mX, mY)) {
                Settings(PerguntasModo[SelecaoP], OperadoresArr[SelecaoO])
                shuffle(res) // array misturar resultados
            //tempo de jogo
                seconds = Math.floor(tempojogo / 1000);
                minutes = Math.floor(seconds / 60);
                seconds = seconds - (minutes * 60);

                criaObjetos(NumQuadrados);//Cria Objetos Alvos com respostas
                timer2 = window.setInterval(PergTimer, 1000) //inicia perguntas e timer
                timer = window.setInterval(AnimaçãoJogo, 50)//Animacao , Desenha e atualiza alvos
                ScreenFlag = 3;
            }
            /*LOAD DO MENU HIGHSCORES
            if (HighScoresO.isInside(mX, mY)) {
                ctx.clearRect(0, 0, 750, 608)
                //Load do ecra HighScores
                //Load do Ficheiro HighScores
                ScreenFlag = 1;
            }*/

            //LOAD DO MENU OPTIONS
            if (OpcoesO.isInside(mX, mY)) {
                OpcoesMenu();
                ScreenFlag = 2;
            }
            break;
        case 1: //ECRA DE HIGHSCORES

            break;
        case 2: //ECRA DE OPTIONS
            for (var i = 0; i < 4; i++) {
                if (ObjetosOpcoes[i].isInside(mX, mY)) {
                    SelecaoO = i;
                    for (var j = 0; j < 4; j++) {
                        ObjetosOpcoes[j].flag = false;
                    }
                    ObjetosOpcoes[i].flag = true;
                }
            }
            for (var i = 4; i < 8; i++) {
                if (ObjetosOpcoes[i].isInside(mX, mY)) {
                    SelecaoP = i - 4;

                    for (var h = 4; h < 8; h++) {
                        console.log(h)
                        ObjetosOpcoes[h].flag = false;
                    }
                    ObjetosOpcoes[i].flag = true;
                }
            }
            ctx.clearRect(0, 0, 750, 608);
            OpcoesMenu()
            for (var i = 0; i < 2; i++) {
                if (ObjetosConfirm[i].isInside(mX, mY)) {
                    if (i == 1) {
                        for (var h = 0; h < 8; h++) {
                            console.log(h)
                            ObjetosOpcoes[h].flag = false;
                        }
                        ObjetosOpcoes[0].flag=true;
                        ObjetosOpcoes[4].flag=true;
                        SelecaoO = 0;
                        SelecaoP = 0;
                        ctx.clearRect(0, 0, 750, 608);
                        OpcoesMenu()
                    }
                    if (i == 0) {
                        ctx.clearRect(0, 0, 750, 608);
                        ScreenFlag = 0;
                        StartMenu();
                    }
                }
            }

            break;
        case 3: //ECRA DE JOGO
            for (var i = 0; i < 12; i++) {
                //Fila Topo
                if (ArrayQuadrados1[i].isInside(mX, mY)) {
                    if (eval(ContaTexto[pergunta]) == ArrayQuadrados1[i].text) {
                        pergunta = pergunta + 1;
                        ArrayQuadrados1[i].img = Alvomarcado
                        ArrayQuadrados1[i].text = "";
                        if (pergunta == PerguntasModo[SelecaoP]) { 
                            EndGame();
                        }
                    }
                    else {
                        ArrayQuadrados1[i].AlvoErrado = 2;
                    }
                }
                //Fila Meio
                if (ArrayQuadrados2[i].isInside(mX, mY)) {
                    if (eval(ContaTexto[pergunta]) == ArrayQuadrados2[i].text) {
                        pergunta = pergunta + 1;
                        ArrayQuadrados2[i].img = Alvomarcado
                        ArrayQuadrados2[i].text = "";
                        if (pergunta == PerguntasModo[SelecaoP]) {
                            EndGame();
                        }
                    }
                    else {
                        ArrayQuadrados2[i].AlvoErrado = 2;
                    }
                }
                //Fila Baixo
                if (ArrayQuadrados3[i].isInside(mX, mY)) {
                    if (eval(ContaTexto[pergunta]) == ArrayQuadrados3[i].text) {
                        pergunta = pergunta + 1;
                        ArrayQuadrados3[i].img = Alvomarcado;
                        ArrayQuadrados3[i].text = "";
                        if (pergunta == PerguntasModo[SelecaoP]) {
                            EndGame();
                        }
                    }
                    else {
                        ArrayQuadrados3[i].AlvoErrado = 2;
                    }
                }
            }
            if (Xbut.isInside(mX, mY)) {
                window.clearInterval(timer)
                window.clearInterval(timer2)
                ScreenFlag = 0;
                ctx.clearRect(0, 0, 750, 608)
                ctx2.clearRect(0, 0, 750, 608)
                perguntaTemp = 0;
                pergunta = 0;
                tp = 0;
                pp = 0;
                StartMenu()
            }
            break;
    }
}
